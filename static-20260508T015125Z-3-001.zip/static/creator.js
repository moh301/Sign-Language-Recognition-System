/**
 * Creator Mode - Real-time Video Recording with Gesture Detection, TTS, and Burned Subtitles
 */

let video = null;
let canvas = null;
let canvasCtx = null;
let audioOutput = null;

let isRecording = false;
let mediaRecorder = null;
let recordedChunks = [];
let detectionInterval = null;
let recordingStartTime = null;
let currentLanguage = 'en';
let detectionRequestInFlight = false;
let renderLoopId = null;

let cameraStream = null;
let ttsAudioContext = null;
let ttsDestination = null;
let ttsSourceNode = null;

let lastRecognizedSigns = [];
let liveTranscript = [];
const SYSTEM_GESTURES = new Set(['NO_HAND', 'NO_SIGN', 'WAITING', 'LOW_CONFIDENCE']);

const LANGUAGE_MAP = {
    en: 'en-US',
    ar: 'ar-SA',
    fr: 'fr-FR',
    es: 'es-ES'
};

const SIGN_TRANSLATIONS = {
    HELLO: { en: 'Hello', ar: 'مرحبا', fr: 'Bonjour', es: 'Hola' },
    GOODBYE: { en: 'Goodbye', ar: 'مع السلامة', fr: 'Au revoir', es: 'Adios' },
    THANK_YOU: { en: 'Thank you', ar: 'شكرا', fr: 'Merci', es: 'Gracias' },
    GOOD: { en: 'Good', ar: 'جيد', fr: 'Bien', es: 'Bueno' },
    BAD: { en: 'Bad', ar: 'سيء', fr: 'Mauvais', es: 'Malo' },
    LOVE: { en: 'Love', ar: 'حب', fr: 'Amour', es: 'Amor' },
    WAIT: { en: 'Wait', ar: 'انتظر', fr: 'Attends', es: 'Espera' },
    SORRY: { en: 'Sorry', ar: 'اسف', fr: 'Desole', es: 'Lo siento' },
    PLEASE: { en: 'Please', ar: 'من فضلك', fr: 'S il vous plait', es: 'Por favor' },
    HELP: { en: 'Help', ar: 'مساعدة', fr: 'Aide', es: 'Ayuda' },
    WATER: { en: 'Water', ar: 'ماء', fr: 'Eau', es: 'Agua' },
    FOOD: { en: 'Food', ar: 'طعام', fr: 'Nourriture', es: 'Comida' },
    SLEEP: { en: 'Sleep', ar: 'نوم', fr: 'Dormir', es: 'Dormir' },
    BATHROOM: { en: 'Bathroom', ar: 'حمام', fr: 'Toilettes', es: 'Bano' },
    PAIN: { en: 'Pain', ar: 'الم', fr: 'Douleur', es: 'Dolor' },
    I: { en: 'I', ar: 'انا', fr: 'Je', es: 'Yo' },
    NEED: { en: 'Need', ar: 'احتاج', fr: 'Besoin', es: 'Necesito' }
};

function isActionableGesture(gesture) {
    return gesture && !SYSTEM_GESTURES.has(gesture);
}

function translateGesture(gesture, language = currentLanguage) {
    const normalizedLanguage = Object.prototype.hasOwnProperty.call(LANGUAGE_MAP, language) ? language : 'en';
    const dictionary = SIGN_TRANSLATIONS[gesture];

    if (dictionary && dictionary[normalizedLanguage]) {
        return dictionary[normalizedLanguage];
    }

    return String(gesture || '')
        .replace(/_/g, ' ')
        .trim();
}

function setTextDirection() {
    const direction = currentLanguage === 'ar' ? 'rtl' : 'ltr';

    const liveTextEl = document.getElementById('liveText');
    const liveTranscriptEl = document.getElementById('liveTranscript');
    const previewTranscriptEl = document.getElementById('previewTranscript');

    if (liveTextEl) {
        liveTextEl.dir = direction;
    }

    if (liveTranscriptEl) {
        liveTranscriptEl.dir = direction;
    }

    if (previewTranscriptEl) {
        previewTranscriptEl.dir = direction;
    }
}

function getPreferredMimeType() {
    const supportedTypes = [
        'video/webm;codecs=vp9,opus',
        'video/webm;codecs=vp8,opus',
        'video/webm'
    ];

    const preferred = supportedTypes.find((type) => MediaRecorder.isTypeSupported(type));
    return preferred || 'video/webm';
}

function drawSubtitleOnCanvas() {
    if (!canvasCtx || !canvas || !video) {
        return;
    }

    canvasCtx.drawImage(video, 0, 0, canvas.width, canvas.height);

    const subtitle = liveTranscript.slice(-6).join(' ');
    if (!subtitle) {
        return;
    }

    const horizontalPadding = Math.floor(canvas.width * 0.04);
    const maxTextWidth = canvas.width - horizontalPadding * 2;
    const fontSize = Math.max(26, Math.floor(canvas.width * 0.032));

    canvasCtx.font = `700 ${fontSize}px Arial`;
    canvasCtx.textAlign = 'center';
    canvasCtx.textBaseline = 'middle';

    const words = subtitle.split(' ');
    const lines = [];
    let currentLine = '';

    for (const word of words) {
        const testLine = currentLine ? `${currentLine} ${word}` : word;
        const testWidth = canvasCtx.measureText(testLine).width;

        if (testWidth > maxTextWidth && currentLine) {
            lines.push(currentLine);
            currentLine = word;
        } else {
            currentLine = testLine;
        }
    }

    if (currentLine) {
        lines.push(currentLine);
    }

    const lineHeight = Math.floor(fontSize * 1.4);
    const totalTextHeight = lines.length * lineHeight;
    const boxPaddingY = Math.floor(fontSize * 0.7);
    const boxHeight = totalTextHeight + boxPaddingY * 2;
    const boxY = canvas.height - boxHeight - Math.floor(canvas.height * 0.03);

    canvasCtx.fillStyle = 'rgba(0, 0, 0, 0.65)';
    canvasCtx.fillRect(horizontalPadding, boxY, canvas.width - horizontalPadding * 2, boxHeight);

    let y = boxY + boxPaddingY + lineHeight / 2;
    for (const line of lines) {
        canvasCtx.lineWidth = Math.max(3, Math.floor(fontSize * 0.12));
        canvasCtx.strokeStyle = 'rgba(0, 0, 0, 0.9)';
        canvasCtx.strokeText(line, canvas.width / 2, y);

        canvasCtx.fillStyle = '#ffffff';
        canvasCtx.fillText(line, canvas.width / 2, y);
        y += lineHeight;
    }
}

function startCanvasRenderLoop() {
    const draw = () => {
        if (!isRecording) {
            renderLoopId = null;
            return;
        }

        drawSubtitleOnCanvas();
        renderLoopId = requestAnimationFrame(draw);
    };

    if (!renderLoopId) {
        renderLoopId = requestAnimationFrame(draw);
    }
}

function stopCanvasRenderLoop() {
    if (renderLoopId) {
        cancelAnimationFrame(renderLoopId);
        renderLoopId = null;
    }
}

async function initCreatorMode() {
    try {
        video = document.getElementById('creatorVideo');
        canvas = document.getElementById('creatorCanvas');
        canvasCtx = canvas ? canvas.getContext('2d') : null;
        audioOutput = document.getElementById('audioOutput');

        document.getElementById('startRecordBtn').addEventListener('click', startRecording);
        document.getElementById('stopRecordBtn').addEventListener('click', stopRecording);
        document.getElementById('languageSelect').addEventListener('change', (event) => {
            currentLanguage = event.target.value;
            setTextDirection();
        });

        document.getElementById('saveVideoBtn').addEventListener('click', saveVideo);
        document.getElementById('downloadVideoBtn').addEventListener('click', downloadVideo);
        document.getElementById('deleteVideoBtn').addEventListener('click', deleteVideo);
        document.getElementById('recordAgainBtn').addEventListener('click', recordAgain);
        document.getElementById('refreshGalleryBtn').addEventListener('click', loadCreatorVideos);

        cameraStream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } },
            audio: false
        });

        video.srcObject = cameraStream;
        await video.play();

        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        if (AudioContextClass) {
            ttsAudioContext = new AudioContextClass();
            ttsDestination = ttsAudioContext.createMediaStreamDestination();

            if (audioOutput) {
                ttsSourceNode = ttsAudioContext.createMediaElementSource(audioOutput);
                ttsSourceNode.connect(ttsDestination);
            }
        }

        setTextDirection();
        loadCreatorVideos();

        console.log('Creator mode initialized with camera video + generated TTS audio track');
    } catch (error) {
        console.error('Error initializing Creator Mode:', error);
        alert('Failed to initialize Creator Mode. Please check camera permission and reload.');
    }
}

async function startRecording() {
    try {
        if (isRecording) {
            return;
        }

        if (!video || !canvas || !canvasCtx) {
            alert('Recording components are not ready yet.');
            return;
        }

        if (ttsAudioContext && ttsAudioContext.state === 'suspended') {
            await ttsAudioContext.resume();
        }

        isRecording = true;
        recordedChunks = [];
        lastRecognizedSigns = [];
        liveTranscript = [];
        recordingStartTime = Date.now();

        const width = video.videoWidth || 1280;
        const height = video.videoHeight || 720;
        canvas.width = width;
        canvas.height = height;

        startCanvasRenderLoop();

        const canvasStream = canvas.captureStream(30);
        const combinedStream = new MediaStream();

        const canvasVideoTrack = canvasStream.getVideoTracks()[0];
        if (canvasVideoTrack) {
            combinedStream.addTrack(canvasVideoTrack);
        }

        const ttsTrack = ttsDestination?.stream?.getAudioTracks?.()[0];
        if (ttsTrack) {
            combinedStream.addTrack(ttsTrack);
        }

        mediaRecorder = new MediaRecorder(combinedStream, {
            mimeType: getPreferredMimeType(),
            videoBitsPerSecond: 2500000
        });

        mediaRecorder.ondataavailable = (event) => {
            if (event.data && event.data.size > 0) {
                recordedChunks.push(event.data);
            }
        };

        mediaRecorder.onstop = handleRecordingStop;
        mediaRecorder.start(250);

        document.getElementById('startRecordBtn').disabled = true;
        document.getElementById('stopRecordBtn').disabled = false;
        document.getElementById('languageSelect').disabled = true;
        document.getElementById('recordingIndicator').style.display = 'inline';

        startLiveDetection();
        updateRecordingTime();

        console.log('Recording started using camera video and generated TTS audio');
    } catch (error) {
        console.error('Error starting recording:', error);
        isRecording = false;
        stopCanvasRenderLoop();
    }
}

function stopRecording() {
    try {
        if (!isRecording || !mediaRecorder) {
            return;
        }

        isRecording = false;
        mediaRecorder.stop();
        stopCanvasRenderLoop();

        if (detectionInterval) {
            clearInterval(detectionInterval);
            detectionInterval = null;
        }

        document.getElementById('startRecordBtn').disabled = false;
        document.getElementById('stopRecordBtn').disabled = true;
        document.getElementById('languageSelect').disabled = false;
        document.getElementById('recordingIndicator').style.display = 'none';

        console.log('Recording stopped');
    } catch (error) {
        console.error('Error stopping recording:', error);
    }
}

function handleRecordingStop() {
    try {
        const blob = new Blob(recordedChunks, { type: 'video/webm' });
        const videoUrl = URL.createObjectURL(blob);

        const previewVideo = document.getElementById('previewVideo');
        previewVideo.src = videoUrl;

        const transcriptText = liveTranscript.join(' ').trim();
        document.getElementById('previewTranscript').textContent = transcriptText || 'No transcript';

        document.getElementById('previewSection').style.display = 'block';

        window.currentRecordedBlob = blob;
        window.currentRecordedTranscript = transcriptText;
        window.currentRecordedLanguage = currentLanguage;

        console.log('Recording processing complete');
    } catch (error) {
        console.error('Error processing recording:', error);
    }
}

function startLiveDetection() {
    detectionInterval = setInterval(async () => {
        if (!isRecording || !video || !canvas || !canvasCtx || detectionRequestInFlight) {
            return;
        }

        try {
            detectionRequestInFlight = true;
            canvasCtx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const imageData = canvas.toDataURL('image/jpeg', 0.8);

            const response = await fetch('/api/detect', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ image: imageData })
            });

            const result = await response.json();
            if (result.success && result.gesture) {
                await updateLiveDetection(result);
            }
        } catch (error) {
            console.error('Error in detection loop:', error);
        } finally {
            detectionRequestInFlight = false;
        }
    }, 120);
}

async function updateLiveDetection(result) {
    try {
        const gesture = result.gesture;
        const confidence = Number(result.confidence || 0);

        const translatedText = translateGesture(gesture, currentLanguage);

        document.getElementById('currentDetection').textContent = isActionableGesture(gesture)
            ? translatedText
            : gesture;
        document.getElementById('confidenceValue').textContent = `${(confidence * 100).toFixed(1)}%`;
        document.getElementById('liveText').textContent = isActionableGesture(gesture)
            ? translatedText
            : 'Waiting...';

        if (isActionableGesture(gesture)) {
            const isNewGesture = lastRecognizedSigns.length === 0 || lastRecognizedSigns[lastRecognizedSigns.length - 1] !== gesture;

            if (isNewGesture) {
                lastRecognizedSigns.push(gesture);
                liveTranscript.push(translatedText);
                document.getElementById('liveTranscript').textContent = liveTranscript.join(' ');

                await speakSign(translatedText);
            }
        }
    } catch (error) {
        console.error('Error updating detection:', error);
    }
}

function playTtsBlob(blob) {
    return new Promise((resolve) => {
        try {
            if (!audioOutput) {
                resolve();
                return;
            }

            const audioUrl = URL.createObjectURL(blob);

            const cleanup = () => {
                audioOutput.onended = null;
                audioOutput.onerror = null;
                URL.revokeObjectURL(audioUrl);
                resolve();
            };

            audioOutput.onended = cleanup;
            audioOutput.onerror = cleanup;
            audioOutput.src = audioUrl;

            audioOutput.play().catch((playError) => {
                console.error('Error playing TTS audio:', playError);
                cleanup();
            });
        } catch (error) {
            console.error('Error in playTtsBlob:', error);
            resolve();
        }
    });
}

function fallbackBrowserTts(text) {
    return new Promise((resolve) => {
        try {
            if (!('speechSynthesis' in window)) {
                resolve();
                return;
            }

            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = LANGUAGE_MAP[currentLanguage] || 'en-US';
            utterance.rate = 0.95;
            utterance.pitch = 1;
            utterance.volume = 1;

            const voices = window.speechSynthesis.getVoices();
            const matchingVoice = voices.find((voice) =>
                voice.lang && voice.lang.toLowerCase().startsWith(currentLanguage)
            );

            if (matchingVoice) {
                utterance.voice = matchingVoice;
            }

            utterance.onend = () => resolve();
            utterance.onerror = () => resolve();

            window.speechSynthesis.cancel();
            window.speechSynthesis.speak(utterance);
        } catch (error) {
            console.error('Fallback browser TTS failed:', error);
            resolve();
        }
    });
}

async function speakSign(text) {
    try {
        const response = await fetch('/api/creator/tts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                text,
                language: currentLanguage
            })
        });

        if (!response.ok) {
            throw new Error('TTS request failed');
        }

        const audioBlob = await response.blob();
        if (!audioBlob || audioBlob.size === 0) {
            throw new Error('Empty TTS audio response');
        }

        await playTtsBlob(audioBlob);
    } catch (error) {
        console.warn('Server TTS failed, using browser fallback:', error);
        await fallbackBrowserTts(text);
    }
}

async function saveVideo() {
    try {
        if (!window.currentRecordedBlob) {
            alert('No video to save');
            return;
        }

        const formData = new FormData();
        formData.append('video', window.currentRecordedBlob, `video_${Date.now()}.webm`);
        formData.append('transcript', window.currentRecordedTranscript || '');
        formData.append('language', window.currentRecordedLanguage || currentLanguage);

        const response = await fetch('/api/creator/save-video', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();
        if (result.success) {
            alert('Video saved successfully');
            recordAgain();
            loadCreatorVideos();
        } else {
            alert(`Error saving video: ${result.message}`);
        }
    } catch (error) {
        console.error('Error saving video:', error);
        alert('Error saving video');
    }
}

async function downloadVideo() {
    try {
        if (!window.currentRecordedBlob) {
            alert('No video to download');
            return;
        }

        const url = URL.createObjectURL(window.currentRecordedBlob);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = `signa_creator_${Date.now()}.webm`;
        document.body.appendChild(anchor);
        anchor.click();
        document.body.removeChild(anchor);
        URL.revokeObjectURL(url);
    } catch (error) {
        console.error('Error downloading video:', error);
    }
}

function deleteVideo() {
    if (!confirm('Are you sure you want to delete this recording?')) {
        return;
    }

    window.currentRecordedBlob = null;
    window.currentRecordedTranscript = '';
    window.currentRecordedLanguage = currentLanguage;
    recordAgain();
}

function recordAgain() {
    document.getElementById('previewSection').style.display = 'none';
    document.getElementById('previewVideo').src = '';
    document.getElementById('previewTranscript').textContent = '';

    isRecording = false;
    recordedChunks = [];
    lastRecognizedSigns = [];
    liveTranscript = [];

    document.getElementById('liveTranscript').textContent = 'Ready to record...';
    document.getElementById('currentDetection').textContent = '—';
    document.getElementById('confidenceValue').textContent = '—';
    document.getElementById('liveText').textContent = 'Waiting...';
    document.getElementById('recordingTime').textContent = '00:00';
    document.getElementById('recordingIndicator').style.display = 'inline';
}

function updateRecordingTime() {
    if (!isRecording) {
        return;
    }

    const elapsed = Math.floor((Date.now() - recordingStartTime) / 1000);
    const minutes = Math.floor(elapsed / 60);
    const seconds = elapsed % 60;

    document.getElementById('recordingTime').textContent =
        `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

    if (isRecording) {
        setTimeout(updateRecordingTime, 1000);
    }
}

async function loadCreatorVideos() {
    try {
        const response = await fetch('/api/creator/get-videos');
        const result = await response.json();

        const gallery = document.getElementById('videosGallery');
        gallery.innerHTML = '';

        if (!result.videos || result.videos.length === 0) {
            gallery.innerHTML = '<p class="empty-message">No videos yet. Create your first creator video!</p>';
            return;
        }

        result.videos.forEach((videoItem) => {
            const transcriptPreview = (videoItem.transcript || '').trim();
            const clippedTranscript = transcriptPreview.length > 60
                ? `${transcriptPreview.substring(0, 60)}...`
                : transcriptPreview || 'No transcript';

            const videoCard = document.createElement('div');
            videoCard.className = 'video-card';
            videoCard.innerHTML = `
                <div class="video-card-thumbnail">
                    <video>
                        <source src="/static/videos/${videoItem.filename}" type="video/webm">
                    </video>
                </div>
                <div class="video-card-info">
                    <div class="video-card-title">${videoItem.filename.split('_').slice(1).join('_')}</div>
                    <div class="video-card-meta">
                        <div>Text: ${clippedTranscript}</div>
                        <div>Date: ${new Date(videoItem.created_at).toLocaleDateString()}</div>
                    </div>
                    <div class="video-card-actions">
                        <button class="video-card-btn play" onclick="playCreatorVideo('${videoItem.filename}')">
                            Play
                        </button>
                        <button class="video-card-btn delete" onclick="deleteCreatorVideo('${videoItem.filename}')">
                            Delete
                        </button>
                    </div>
                </div>
            `;
            gallery.appendChild(videoCard);
        });
    } catch (error) {
        console.error('Error loading videos:', error);
    }
}

async function playCreatorVideo(filename) {
    try {
        const response = await fetch(`/api/creator/get-video/${filename}`);
        const result = await response.json();

        const previewVideo = document.getElementById('previewVideo');
        previewVideo.src = `/static/videos/${filename}`;

        document.getElementById('previewTranscript').textContent = result.transcript || 'No transcript available';
        document.getElementById('previewSection').style.display = 'block';

        document.querySelector('.preview-section').scrollIntoView({ behavior: 'smooth' });
    } catch (error) {
        console.error('Error playing video:', error);
    }
}

async function deleteCreatorVideo(filename) {
    if (!confirm('Are you sure you want to delete this video?')) {
        return;
    }

    try {
        const response = await fetch(`/api/creator/delete-video/${filename}`, {
            method: 'DELETE'
        });

        const result = await response.json();
        if (result.success) {
            alert('Video deleted');
            loadCreatorVideos();
        } else {
            alert('Error deleting video');
        }
    } catch (error) {
        console.error('Error deleting video:', error);
    }
}

document.addEventListener('DOMContentLoaded', initCreatorMode);

window.addEventListener('beforeunload', () => {
    if (isRecording) {
        stopRecording();
    }

    if (detectionInterval) {
        clearInterval(detectionInterval);
        detectionInterval = null;
    }

    stopCanvasRenderLoop();

    if (cameraStream) {
        cameraStream.getTracks().forEach((track) => track.stop());
    }

    if (ttsAudioContext && ttsAudioContext.state !== 'closed') {
        ttsAudioContext.close().catch(() => {});
    }
});
