/**
 * Real-time Gesture Detection with Text-to-Speech
 * Captures video frames and sends them to backend for recognition
 */

let video = null;
let canvas = null;
let canvasCtx = null;
let isDetectionActive = false;
let detectionInterval = null;
let autoSpeak = true;
let lastHandledGesture = null;
let lastSpeakableGesture = null;

const SYSTEM_GESTURES = new Set(['NO_HAND', 'NO_SIGN', 'WAITING', 'LOW_CONFIDENCE']);

function isActionableGesture(gesture) {
    return gesture && !SYSTEM_GESTURES.has(gesture);
}

function updateStatusText(statusText) {
    const statStatus = document.getElementById('statStatus');
    if (statStatus) {
        statStatus.textContent = statusText;
    }
}

function setSpeakButtonState(enabled) {
    const speakBtn = document.getElementById('speakBtn');
    if (speakBtn) {
        speakBtn.disabled = !enabled;
    }
}

function updateAutoSpeakButton() {
    const btn = document.getElementById('autoSpeakToggle');
    if (!btn) return;

    btn.classList.remove('auto-speak-on', 'auto-speak-off');

    if (autoSpeak) {
        btn.innerHTML = '<i class="fa-solid fa-volume-high auto-speak-icon" aria-hidden="true"></i><span>Auto Speech: ON</span>';
        btn.classList.add('auto-speak-on');
    } else {
        btn.innerHTML = '<i class="fa-solid fa-volume-xmark auto-speak-icon" aria-hidden="true"></i><span>Auto Speech: OFF</span>';
        btn.classList.add('auto-speak-off');
    }
}

function updateStats(signs) {
    const statCount = document.getElementById('statCount');
    const statConfidence = document.getElementById('statConfidence');

    if (statCount) {
        statCount.textContent = signs.length;
    }

    if (statConfidence) {
        if (signs.length === 0) {
            statConfidence.textContent = '0%';
        } else {
            const sum = signs.reduce((acc, item) => acc + (Number(item.confidence) || 0), 0);
            const avg = Math.round(sum / signs.length);
            statConfidence.textContent = avg + '%';
        }
    }
}

function getDetectionStatusLabel(gesture, confidence) {
    if (!isDetectionActive) return 'Stopped';
    if (gesture === 'NO_HAND') return 'No Hand';
    if (gesture === 'LOW_CONFIDENCE' || confidence < 0.8) return 'Low Confidence';
    if (gesture === 'WAITING') return 'Waiting';
    if (gesture === 'NO_SIGN') return 'No Sign';
    return 'Detecting';
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    video = document.getElementById('video');
    canvas = document.getElementById('canvas');
    if (canvas) {
        canvasCtx = canvas.getContext('2d');
    }
    
    const startBtn = document.getElementById('startBtn');
    const stopBtn = document.getElementById('stopBtn');
    const clearBtn = document.getElementById('clearBtn');
    const autoSpeakBtn = document.getElementById('autoSpeakToggle');
    const speakBtn = document.getElementById('speakBtn');
    
    if (startBtn) startBtn.addEventListener('click', startDetection);
    if (stopBtn) stopBtn.addEventListener('click', stopDetection);
    if (clearBtn) clearBtn.addEventListener('click', clearHistory);
    if (autoSpeakBtn) autoSpeakBtn.addEventListener('click', toggleAutoSpeak);
    if (speakBtn) speakBtn.addEventListener('click', speakLastSign);
    updateAutoSpeakButton();
    
    // Load initial sign history
    loadSignHistory();
    updateStatusText('Ready');
});

// Start detection
async function startDetection() {
    try {
        console.log("Starting detection...");
        
        // Request camera access with support for camera selection
        const videoConstraints = window.getCameraConstraints 
            ? window.getCameraConstraints() 
            : {
                facingMode: 'user',
                width: { ideal: 640 },
                height: { ideal: 480 }
            };
        
        const stream = await navigator.mediaDevices.getUserMedia({
            video: videoConstraints
        });
        
        video.srcObject = stream;
        isDetectionActive = true;
        lastHandledGesture = null;
        
        // Update UI
        document.getElementById('startBtn').disabled = true;
        document.getElementById('stopBtn').disabled = false;
        
        // Start detection loop
        detectionInterval = setInterval(captureAndDetect, 500); // Every 500ms
        updateStatusText('Detecting');
        
        console.log("Detection started!");
    } catch (error) {
        console.error('Error accessing camera:', error);
        alert('Could not access camera. Please check permissions.');
    }
}

// Stop detection
function stopDetection() {
    console.log("Stopping detection...");
    
    isDetectionActive = false;
    lastHandledGesture = null;
    
    if (detectionInterval) {
        clearInterval(detectionInterval);
        detectionInterval = null;
    }
    
    if (video.srcObject) {
        video.srcObject.getTracks().forEach(track => track.stop());
    }
    
    // Update UI
    document.getElementById('startBtn').disabled = false;
    document.getElementById('stopBtn').disabled = true;
    updateStatusText('Stopped');
    
    console.log("Detection stopped!");
}

// Capture frame from video and send for detection
async function captureAndDetect() {
    if (!isDetectionActive || !video || !canvas) return;
    
    try {
        // Draw current video frame to canvas
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        
        if (canvas.width === 0 || canvas.height === 0) return;
        
        canvasCtx.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        // Get image data as base64
        const imageData = canvas.toDataURL('image/png');
        
        // Send to backend for detection
        const response = await fetch('/api/detect', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                image: imageData
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            const gesture = result.gesture;
            const confidence = result.confidence;
            
            // Update current sign display
            updateCurrentSign(gesture, confidence);
            updateStatusText(getDetectionStatusLabel(gesture, confidence));
            
            const changedFromLast = gesture !== lastHandledGesture;

            // Only process a sign if it changed and it's not a system status.
            if (changedFromLast && isActionableGesture(gesture) && autoSpeak && confidence > 0.7) {
                speakGesture(gesture);
            }
            
            // Save only actionable changed signs.
            if (changedFromLast && isActionableGesture(gesture) && confidence > 0.6) {
                lastSpeakableGesture = gesture;
                setSpeakButtonState(true);
                await saveSign(gesture, confidence);
            }

            if (changedFromLast) {
                lastHandledGesture = gesture;
            }
        }
    } catch (error) {
        console.error('Error during detection:', error);
    }
}

// Update current sign display
function updateCurrentSign(gesture, confidence) {
    const currentSignEl = document.getElementById('currentSign');
    const confidenceEl = document.getElementById('confidence');
    
    if (currentSignEl && confidenceEl) {
        const signText = currentSignEl.querySelector('.sign-text');
        if (signText) {
            signText.textContent = gesture;
        }
        
        const confPercent = Math.round(confidence * 100);
        confidenceEl.textContent = confPercent + '%';
        
        // Change color based on confidence
        if (confidence > 0.8) {
            currentSignEl.style.backgroundColor = '#d4edda';
            currentSignEl.style.borderColor = '#28a745';
        } else if (confidence > 0.6) {
            currentSignEl.style.backgroundColor = '#fff3cd';
            currentSignEl.style.borderColor = '#ffc107';
        } else {
            currentSignEl.style.backgroundColor = '#f8d7da';
            currentSignEl.style.borderColor = '#dc3545';
        }
    }
}

// نطق الكلمة
function speakGesture(gesture) {
    // قاموس الترجمات للأربع لغات
    const translations = {
        'HELLO': { en: 'Hello', ar: 'مرحبا', fr: 'Bonjour', es: 'Hola' },
        'GOODBYE': { en: 'Goodbye', ar: 'مع السلامة', fr: 'Au revoir', es: 'Adiós' },
        'THANK_YOU': { en: 'Thank you', ar: 'شكرا', fr: 'Merci', es: 'Gracias' },
        'GOOD': { en: 'Good', ar: 'جيد', fr: 'Bien', es: 'Bien' },
        'BAD': { en: 'Bad', ar: 'سيء', fr: 'Mauvais', es: 'Malo' },
        'LOVE': { en: 'Love', ar: 'حب', fr: 'Amour', es: 'Amor' },
        'WAIT': { en: 'Wait', ar: 'انتظر', fr: 'Attends', es: 'Espera' },
        'SORRY': { en: 'Sorry', ar: 'آسف', fr: 'Désolé', es: 'Lo siento' },
        'PLEASE': { en: 'Please', ar: 'من فضلك', fr: "S'il vous plaît", es: 'Por favor' },
        'HELP': { en: 'Help', ar: 'مساعدة', fr: 'Aide', es: 'Ayuda' },
        'WATER': { en: 'Water', ar: 'ماء', fr: 'Eau', es: 'Agua' },
        'FOOD': { en: 'Food', ar: 'طعام', fr: 'Nourriture', es: 'Comida' },
        'SLEEP': { en: 'Sleep', ar: 'نوم', fr: 'Dormir', es: 'Dormir' },
        'BATHROOM': { en: 'Bathroom', ar: 'حمام', fr: 'Toilettes', es: 'Baño' },
        'PAIN': { en: 'Pain', ar: 'ألم', fr: 'Douleur', es: 'Dolor' },
        'I': { en: 'I', ar: 'أنا', fr: 'Je', es: 'Yo' },
        'NEED': { en: 'Need', ar: 'أحتاج', fr: 'Besoin', es: 'Necesito' }
    };

    const langToLocale = {
        en: 'en-US',
        ar: 'ar-SA',
        fr: 'fr-FR',
        es: 'es-ES'
    };
    
    // احصل على اللغة المختارة (افتراضي: إنجليزي)
    const langSelect = document.getElementById('voiceSelect');
    const selectedLang = langSelect ? langSelect.value : 'en';
    const normalizedLang = langToLocale[selectedLang] ? selectedLang : 'en';
    
    // احصل على النص المراد نطقه
    const textToSpeak = translations[gesture] && translations[gesture][normalizedLang]
        ? translations[gesture][normalizedLang]
        : gesture.replace(/_/g, ' ');
    
    // استخدم Web Speech API
    if ('speechSynthesis' in window) {
        // ألغي أي كلام جاري
        window.speechSynthesis.cancel();
        
        const utterance = new SpeechSynthesisUtterance(textToSpeak);
        utterance.lang = langToLocale[normalizedLang];
        utterance.rate = 0.9;
        utterance.pitch = 1;
        utterance.volume = 1;

        // اختار صوت مطابق للغة المختارة إن وجد
        const voices = window.speechSynthesis.getVoices();
        const matchingVoice = voices.find((voice) =>
            voice.lang && voice.lang.toLowerCase().startsWith(normalizedLang)
        );
        if (matchingVoice) {
            utterance.voice = matchingVoice;
        }
        
        console.log(`Speaking: ${textToSpeak} (${normalizedLang})`);
        window.speechSynthesis.speak(utterance);
    }
}

function speakLastSign() {
    let gestureToSpeak = lastSpeakableGesture;

    if (!gestureToSpeak) {
        const signTextEl = document.querySelector('#currentSign .sign-text');
        const currentGesture = signTextEl ? signTextEl.textContent.trim() : '';
        if (isActionableGesture(currentGesture)) {
            gestureToSpeak = currentGesture;
        }
    }

    if (!gestureToSpeak) {
        console.log('No actionable sign available to speak.');
        return;
    }

    speakGesture(gestureToSpeak);
}

// Save detected sign
async function saveSign(gesture, confidence) {
    try {
        const response = await fetch('/api/save-sign', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                sign: gesture,
                confidence: confidence
            })
        });
        
        const result = await response.json();
        if (result.success) {
            console.log('Sign saved:', gesture);
            loadSignHistory();
        }
    } catch (error) {
        console.error('Error saving sign:', error);
    }
}

// Load and display sign history
async function loadSignHistory() {
    try {
        const response = await fetch('/api/get-signs');
        const result = await response.json();
        
        const historyList = document.getElementById('historyList');
        if (!historyList) return;
        
        const signs = result.signs || [];
        updateStats(signs);

        const latestSpeakableSign = [...signs].reverse().find((item) => isActionableGesture(item.sign));
        if (latestSpeakableSign) {
            lastSpeakableGesture = latestSpeakableSign.sign;
            setSpeakButtonState(true);
        } else {
            lastSpeakableGesture = null;
            setSpeakButtonState(false);
        }
        
        if (signs.length === 0) {
            historyList.innerHTML = '<p>No signs detected yet</p>';
            return;
        }
        
        // Display last 10 signs in reverse order
        const recentSigns = signs.slice(-10).reverse();
        historyList.innerHTML = recentSigns.map((item, index) => `
            <div class="history-item">
                <span class="sign-name">${item.sign}</span>
                <span class="sign-conf">${item.confidence}%</span>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error loading history:', error);
    }
}

// Clear history
async function clearHistory() {
    if (!confirm('Clear all sign history?')) return;
    
    try {
        const response = await fetch('/api/clear-signs', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        });
        
        const result = await response.json();
        if (result.success) {
            loadSignHistory();
            lastHandledGesture = null;
            lastSpeakableGesture = null;
            setSpeakButtonState(false);
            console.log('History cleared');
        }
    } catch (error) {
        console.error('Error clearing history:', error);
    }
}

// Refresh history every 2 seconds while detecting
setInterval(() => {
    if (isDetectionActive) {
        loadSignHistory();
    }
}, 2000);

// Toggle auto-speak
function toggleAutoSpeak() {
    autoSpeak = !autoSpeak;
    updateAutoSpeakButton();
    console.log('Auto speech:', autoSpeak ? 'ON' : 'OFF');
}
