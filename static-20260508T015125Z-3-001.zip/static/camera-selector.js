/**
 * Camera Selection Module
 * Handles camera enumeration and switching
 * Fully isolated - does not interfere with detection.js
 */

let availableCameras = [];
let selectedCameraDeviceId = null;

/**
 * Get all available video input devices
 */
async function getAvailableCameras() {
    try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        availableCameras = devices.filter(device => device.kind === 'videoinput');
        return availableCameras;
    } catch (error) {
        console.error('Error enumerating devices:', error);
        return [];
    }
}

/**
 * Open camera selection modal
 */
async function openCameraSelector() {
    const modal = document.getElementById('cameraModal');
    if (!modal) {
        console.error('Camera modal not found');
        return;
    }

    // Get fresh list of cameras
    const cameras = await getAvailableCameras();
    
    const cameraList = document.getElementById('cameraList');
    if (!cameraList) return;

    if (cameras.length === 0) {
        cameraList.innerHTML = '<p class="no-cameras">No cameras found on this device</p>';
        modal.style.display = 'block';
        return;
    }

    // Build camera list with options
    cameraList.innerHTML = cameras.map((camera, index) => `
        <div class="camera-option" data-device-id="${camera.deviceId}">
            <div class="camera-option-icon">
                <i class="fa-solid fa-camera"></i>
            </div>
            <div class="camera-option-info">
                <div class="camera-option-name">${camera.label || `Camera ${index + 1}`}</div>
                <div class="camera-option-id">${camera.deviceId.substring(0, 20)}...</div>
            </div>
            <div class="camera-option-check">
                <i class="fa-solid fa-check"></i>
            </div>
        </div>
    `).join('');

    // Add click listeners to camera options
    document.querySelectorAll('.camera-option').forEach(option => {
        option.addEventListener('click', () => selectCamera(option.dataset.deviceId));
    });

    // Show modal
    modal.style.display = 'block';
}

/**
 * Close camera selection modal
 */
function closeCameraSelector() {
    const modal = document.getElementById('cameraModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

/**
 * Select a camera and switch to it
 */
async function selectCamera(deviceId) {
    try {
        // Store the selected device ID
        selectedCameraDeviceId = deviceId;
        localStorage.setItem('selectedCameraDeviceId', deviceId);

        // Close modal
        closeCameraSelector();

        // If detection is currently active, we need to restart it with the new camera
        if (isDetectionActive) {
            console.log('Switching camera while detection is active...');
            
            // Stop current detection
            stopDetection();
            
            // Small delay to ensure cleanup
            await new Promise(resolve => setTimeout(resolve, 300));
            
            // Restart detection with new camera
            startDetection();
        } else {
            console.log('Camera selected. It will be used when you start detection.');
        }
    } catch (error) {
        console.error('Error selecting camera:', error);
        alert('Failed to select camera. Please try again.');
    }
}

/**
 * Get the constraints object for getUserMedia
 * This is called from detection.js
 */
function getCameraConstraints() {
    const baseConstraints = {
        facingMode: 'user',
        width: { ideal: 640 },
        height: { ideal: 480 }
    };

    // If a specific camera is selected, use its deviceId
    if (selectedCameraDeviceId) {
        return {
            deviceId: { exact: selectedCameraDeviceId },
            width: { ideal: 640 },
            height: { ideal: 480 }
        };
    }

    return baseConstraints;
}

/**
 * Initialize camera selector
 */
async function initCameraSelector() {
    // Load saved camera preference
    const savedCameraId = localStorage.getItem('selectedCameraDeviceId');
    if (savedCameraId) {
        selectedCameraDeviceId = savedCameraId;
    }

    // Set up modal close button
    const closeBtn = document.getElementById('cameraSelectorClose');
    if (closeBtn) {
        closeBtn.addEventListener('click', closeCameraSelector);
    }

    // Set up camera modal button
    const cameraBtn = document.getElementById('cameraBtn');
    if (cameraBtn) {
        cameraBtn.addEventListener('click', openCameraSelector);
    }

    // Close modal when clicking outside of it
    const modal = document.getElementById('cameraModal');
    if (modal) {
        window.addEventListener('click', function(event) {
            if (event.target === modal) {
                closeCameraSelector();
            }
        });
    }

    console.log('Camera selector initialized');
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCameraSelector);
} else {
    initCameraSelector();
}
